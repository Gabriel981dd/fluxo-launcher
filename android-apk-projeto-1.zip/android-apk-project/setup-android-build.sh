#!/bin/bash

set -e

echo "========================================"
echo "  Configuracao do Ambiente Android Build"
echo "========================================"

ANDROID_HOME="$HOME/android-sdk"
CMDLINE_TOOLS_URL="https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip"
CMDLINE_TOOLS_ZIP="commandlinetools.zip"

JAVA_VERSION=$(java -version 2>&1 | head -n 1)
if [ $? -ne 0 ]; then
  echo ""
  echo "[ERRO] Java nao encontrado. Instale o JDK 17 antes de continuar:"
  echo "  Ubuntu/Debian: sudo apt install openjdk-17-jdk"
  echo "  macOS:         brew install openjdk@17"
  echo "  Windows:       https://adoptium.net/"
  exit 1
fi
echo "[OK] Java encontrado: $JAVA_VERSION"

echo ""
echo "[1/4] Criando pasta do Android SDK em: $ANDROID_HOME"
mkdir -p "$ANDROID_HOME/cmdline-tools"

echo "[2/4] Baixando Android Command-line Tools..."
curl -L "$CMDLINE_TOOLS_URL" -o "$CMDLINE_TOOLS_ZIP"

echo "[3/4] Extraindo ferramentas..."
unzip -q "$CMDLINE_TOOLS_ZIP" -d "$ANDROID_HOME/cmdline-tools"
mv "$ANDROID_HOME/cmdline-tools/cmdline-tools" "$ANDROID_HOME/cmdline-tools/latest"
rm "$CMDLINE_TOOLS_ZIP"

echo "[4/4] Configurando variaveis de ambiente..."
SHELL_CONFIG=""
if [ -f "$HOME/.bashrc" ]; then
  SHELL_CONFIG="$HOME/.bashrc"
elif [ -f "$HOME/.zshrc" ]; then
  SHELL_CONFIG="$HOME/.zshrc"
else
  SHELL_CONFIG="$HOME/.profile"
fi

grep -qxF "export ANDROID_HOME=$ANDROID_HOME" "$SHELL_CONFIG" || cat >> "$SHELL_CONFIG" << EOF

# Android SDK
export ANDROID_HOME=$ANDROID_HOME
export PATH=\$PATH:\$ANDROID_HOME/cmdline-tools/latest/bin
export PATH=\$PATH:\$ANDROID_HOME/platform-tools
export PATH=\$PATH:\$ANDROID_HOME/build-tools/34.0.0
EOF

export ANDROID_HOME=$ANDROID_HOME
export PATH=$PATH:$ANDROID_HOME/cmdline-tools/latest/bin
export PATH=$PATH:$ANDROID_HOME/platform-tools
export PATH=$PATH:$ANDROID_HOME/build-tools/34.0.0

echo ""
echo "========================================"
echo "  Instalando SDK components..."
echo "========================================"

yes | sdkmanager --licenses > /dev/null 2>&1 || true

sdkmanager \
  "platform-tools" \
  "build-tools;34.0.0" \
  "platforms;android-34" \
  "extras;android;m2repository" \
  "extras;google;m2repository"

echo ""
echo "========================================"
echo "  Instalacao concluida com sucesso!"
echo "========================================"
echo ""
echo "Ferramentas instaladas:"
echo "  - Android SDK Platform 34 (Android 14)"
echo "  - Build Tools 34.0.0"
echo "  - Platform Tools (adb, fastboot)"
echo "  - Maven Repositories"
echo ""
echo "Para compilar um APK do seu projeto:"
echo ""
echo "  1. Projeto Expo/React Native:"
echo "     npm install -g eas-cli"
echo "     eas build --platform android --profile preview"
echo ""
echo "  2. Projeto Android nativo (Gradle):"
echo "     cd seu-projeto-android"
echo "     ./gradlew assembleDebug        # APK de debug"
echo "     ./gradlew assembleRelease      # APK de release (requer keystore)"
echo ""
echo "  3. Gerar keystore para release (necessario apenas 1 vez):"
echo "     keytool -genkey -v -keystore meu-app.keystore \\"
echo "             -alias meu-app -keyalg RSA -keysize 2048 -validity 10000"
echo ""
echo "IMPORTANTE: Execute o seguinte comando para recarregar o PATH:"
echo "  source $SHELL_CONFIG"
echo ""
