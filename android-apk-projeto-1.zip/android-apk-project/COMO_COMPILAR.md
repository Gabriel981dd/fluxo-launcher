# Como Compilar o APK

## Pré-requisitos

1. **Java 17** instalado
   - Ubuntu/Debian: `sudo apt install openjdk-17-jdk`
   - macOS: `brew install openjdk@17`
   - Windows: https://adoptium.net/

2. **Android SDK** configurado (rode o script `setup-android-build.sh`)

---

## Passo a Passo

### 1. Configurar o Android SDK (apenas na primeira vez)

```bash
chmod +x setup-android-build.sh
./setup-android-build.sh
source ~/.bashrc   # ou ~/.zshrc no macOS
```

### 2. Entrar na pasta do projeto

```bash
cd android-apk-project
```

### 3. Dar permissão ao Gradle wrapper

```bash
chmod +x gradlew
```

### 4. Compilar APK de Debug (mais simples, não precisa de assinatura)

```bash
./gradlew assembleDebug
```

O APK gerado estará em:
```
app/build/outputs/apk/debug/app-debug.apk
```

### 5. Compilar APK de Release (para distribuição)

Primeiro, gere um keystore de assinatura (apenas uma vez):

```bash
keytool -genkey -v \
  -keystore meu-app.keystore \
  -alias meu-app \
  -keyalg RSA \
  -keysize 2048 \
  -validity 10000
```

Depois, adicione as configurações de assinatura no `app/build.gradle`:

```gradle
android {
    signingConfigs {
        release {
            storeFile file("../../meu-app.keystore")
            storePassword "sua_senha"
            keyAlias "meu-app"
            keyPassword "sua_senha"
        }
    }
    buildTypes {
        release {
            signingConfig signingConfigs.release
        }
    }
}
```

E compile:

```bash
./gradlew assembleRelease
```

O APK estará em:
```
app/build/outputs/apk/release/app-release.apk
```

---

## Personalizar o App

| O que mudar | Onde mudar |
|---|---|
| Nome do app | `app/src/main/res/values/strings.xml` |
| Tela principal | `app/src/main/res/layout/activity_main.xml` |
| Lógica principal | `app/src/main/java/com/example/app/MainActivity.java` |
| Cores | `app/src/main/res/values/themes.xml` |
| ID do app | `app/build.gradle` → `applicationId` |
| Versão | `app/build.gradle` → `versionCode` / `versionName` |

---

## Estrutura do Projeto

```
android-apk-project/
├── app/
│   ├── src/main/
│   │   ├── java/com/example/app/
│   │   │   └── MainActivity.java       ← Lógica da tela principal
│   │   ├── res/
│   │   │   ├── layout/activity_main.xml ← Layout da tela
│   │   │   └── values/
│   │   │       ├── strings.xml          ← Textos do app
│   │   │       └── themes.xml           ← Cores e estilos
│   │   └── AndroidManifest.xml          ← Configurações do app
│   └── build.gradle                     ← Dependências e config de build
├── gradle/wrapper/
│   └── gradle-wrapper.properties        ← Versão do Gradle
├── build.gradle                         ← Config raiz
├── settings.gradle                      ← Nome e módulos do projeto
└── COMO_COMPILAR.md                     ← Este arquivo
```
