# Regras ProGuard para o projeto
# Adicione regras especificas do seu projeto aqui
